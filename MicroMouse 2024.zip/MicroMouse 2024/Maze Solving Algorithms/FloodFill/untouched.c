#include <stdio.h>
#include <stdbool.h>

#include "API.h" // Remove

#define MAZE_SIZE 16

#define NULL 0

// Initialize maze representation (No walls)
bool horizontalWalls[MAZE_SIZE][MAZE_SIZE + 1];
bool verticalWalls[MAZE_SIZE + 1][MAZE_SIZE];

// Initialize manhattan distances array (all -1 initially)
int manhattanDistances[MAZE_SIZE][MAZE_SIZE];

// Array stating cell is visited or not
bool isVisited[MAZE_SIZE][MAZE_SIZE];

// Get starting position (start cell coordinates)
int startX = 0;
int startY = 0;

// Get goal cell coordinates (assuming there's only one goal)
int goalX = 8;
int goalY = 8;

// Structure to represent each cell(in form of coordinates)
typedef struct
{
    int x;
    int y;
} Cell;

// Keeping track of current orientation
int current_orientation = 0;
char dir[4] = {'n', 'e', 's', 'w'};

// Current cell position
int currentX;
int currentY;

int isMove = 0;

void log(char *text) // Remove
{
    fprintf(stderr, "%s\n", text);
    fflush(stderr);
}

char *convertNumberToString(int num)
{
    static char buffer[32]; // Buffer to store the string representation
    int length = snprintf(buffer, sizeof(buffer), "%d", num);
    if (length >= 0)
    {
        return buffer;
    }
    else
    {
        // Handle potential errors (e.g., buffer overflow)
        return NULL;
    }
}

// Dequeue a cell from the queue (circular array implementation)
Cell *dequeue(Cell queue[40], int *front, int *rear)
{
    if (*front == -1)
    {
        return NULL; // Queue is empty
    }

    Cell *cell = &queue[*front];

    if (*front == *rear)
    {
        *front = *rear = -1; // Reset front and rear if queue becomes empty
    }
    else
    {
        *front = (*front + 1) % 40; // Update front index (circular)
    }

    return cell;
}

// Enqueue a Cell into queue (circular array implementation)
void enqueue(Cell queue[40], int *front, int *rear, Cell cell)
{
    *rear = (*rear + 1) % 40; // Update rear index (circular)

    if (*front == -1)
    {
        *front = 0; // Initialize front if queue was empty
    }

    // Check for overflow (avoid overwriting existing elements)
    if ((*rear + 1) % 40 == *front)
    {
        printf("Queue overflow!\n");
        return;
    }

    queue[*rear] = cell; // Add cell to the queue
}

// FloodFill function to repopulate the ManhattenDistances array
void FloodFill(bool horizontalWalls[MAZE_SIZE][MAZE_SIZE + 1], bool verticalWalls[MAZE_SIZE + 1][MAZE_SIZE], int manhattanDistances[MAZE_SIZE][MAZE_SIZE], int goalX, int goalY)
{
    API_clearAllText(); // Remove

    // Initialize all cells (except goal) to blank state (-1)
    for (int i = 0; i < MAZE_SIZE; i++)
    {
        for (int j = 0; j < MAZE_SIZE; j++)
        {
            manhattanDistances[i][j] = -1;
        }
    }

    // Set goal cell(s) value to 0 and add to queue
    manhattanDistances[goalX][goalY] = 0;
    Cell queue[40];
    int front = -1;
    int rear = -1;
    enqueue(queue, &front, &rear, (Cell){goalX, goalY});

    while (front != -1)
    {
        log("\nFront & rear index: ");             // Remove
        log((char *)convertNumberToString(front)); // Remove
        log((char *)convertNumberToString(rear));  // Remove

        // log("Running...");
        Cell currentCell = *dequeue(queue, &front, &rear);
        int currentX = currentCell.x;
        int currentY = currentCell.y;

        log("\nFront cell: ");                             // Remove
        log((char *)convertNumberToString(currentCell.x)); // Remove
        log((char *)convertNumberToString(currentCell.y)); // Remove

        log("\nFront & rear index: ");             // Remove
        log((char *)convertNumberToString(front)); // Remove
        log((char *)convertNumberToString(rear));  // Remove
        log("\n");                                 // Remove

        // Check and update accessible neighbors (only north, south, east, west and Not Diagonal cells)
        // Check every other value (skip 0 for no diagonal movement)
        for (int dx = -1; dx <= 1; dx += 2)
        {
            int dy = 0; // Only check left and right cells

            int neighborX = currentX + dx;
            int neighborY = currentY + dy;

            // Skip current cell and check if neighbor is within maze boundaries
            if (neighborX < 0 || neighborX >= MAZE_SIZE || neighborY < 0 || neighborY >= MAZE_SIZE)
            {
                continue;
            }

            // Check if neighbor is accessible (not a wall based on direction)
            bool isAccessible = true;
            if (dx == -1)
            { // Checking left neighbor
                isAccessible = !verticalWalls[currentX][currentY];
            }
            else if (dx == 1)
            { // Checking right neighbor
                isAccessible = !verticalWalls[currentX + 1][currentY];
            }

            // Checking if neighbour is accessible and in a blank state
            if (isAccessible && manhattanDistances[neighborX][neighborY] == -1)
            {
                API_setText(neighborX, neighborY, (char *)convertNumberToString(manhattanDistances[currentX][currentY] + 1)); // Remove

                log("-----------Assigning Manhatten Distance & Adding to Cell to Queue-------------"); // Remove
                log((char *)convertNumberToString(neighborX));
                log((char *)convertNumberToString(neighborY));
                log((char *)convertNumberToString(manhattanDistances[currentX][currentY] + 1));

                manhattanDistances[neighborX][neighborY] = manhattanDistances[currentX][currentY] + 1;
                enqueue(queue, &front, &rear, (Cell){neighborX, neighborY});
            }
        }

        for (int dy = -1; dy <= 1; dy += 2)
        {               // Check every other value (skip 0 for no diagonal movement)
            int dx = 0; // Only check front and back cell

            int neighborX = currentX + dx;
            int neighborY = currentY + dy;

            // Skip current cell and check if neighbor is within maze boundaries
            if (neighborX < 0 || neighborX >= MAZE_SIZE || neighborY < 0 || neighborY >= MAZE_SIZE)
            {
                continue;
            }

            // Check if neighbor is accessible (not a wall based on direction)
            bool isAccessible = true;
            if (dy == -1)
            { // Checking bottom neighbor
                isAccessible = !horizontalWalls[currentX][currentY];
            }
            else if (dy == 1)
            { // Checking front neighbor
                isAccessible = !horizontalWalls[currentX][currentY + 1];
            }

            // Checking if neighbour is accessible and in a blank state
            if (isAccessible && manhattanDistances[neighborX][neighborY] == -1)
            {
                API_setText(neighborX, neighborY, (char *)convertNumberToString(manhattanDistances[currentX][currentY] + 1)); // Remove

                log("-----------Assigning Manhatten Distance & Adding to Cell to Queue-------------");
                log((char *)convertNumberToString(neighborX)); // Remove
                log((char *)convertNumberToString(neighborY));
                log((char *)convertNumberToString(manhattanDistances[currentX][currentY] + 1));

                manhattanDistances[neighborX][neighborY] = manhattanDistances[currentX][currentY] + 1;
                enqueue(queue, &front, &rear, (Cell){neighborX, neighborY});
            }
        }
    }
}

void scanCellWalls(int currentX, int currentY)
{
    // Update maze representation based on detected walls (optional)
    if (API_wallLeft())
    {
        switch (current_orientation)
        {
        case 0:
            verticalWalls[currentX][currentY] = true;
            break;
        case 1:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        case 2:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 3:
            horizontalWalls[currentX][currentY] = true;
            break;
        default:
            log("\nInvalid Orientation\n");
            break;
        }
        API_setWall(currentX, currentY, dir[(current_orientation - 1 + 4) % 4]);
    }
    if (API_wallRight())
    {
        switch (current_orientation)
        {
        case 0:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 1:
            horizontalWalls[currentX][currentY] = true;
            break;
        case 2:
            verticalWalls[currentX][currentY] = true;
            break;
        case 3:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        default:
            log("\nInvalid Orientation\n");
            break;
        }
        API_setWall(currentX, currentY, dir[(current_orientation + 1) % 4]);
    }
    if (API_wallFront())
    {
        switch (current_orientation)
        {
        case 0:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        case 1:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 2:
            horizontalWalls[currentX][currentY] = true;
            break;
        case 3:
            verticalWalls[currentX][currentY] = true;
            break;
        default:
            log("\nInvalid Orientation\n");
            break;
        }
        API_setWall(currentX, currentY, dir[current_orientation]);
    }
}

int main()
{
    // *--Remove
    log("Running...");

    // Get maze dimensions
    int mazeWidth = API_mazeWidth();
    int mazeHeight = API_mazeHeight();
    log("mazeWidth: ");
    log((char *)convertNumberToString(mazeWidth));
    log("mazeHeight: ");
    log((char *)convertNumberToString(mazeHeight));

    // Check if provided dimensions match expected MAZE_SIZE
    if (mazeWidth != MAZE_SIZE || mazeHeight != MAZE_SIZE)
    {
        // log("Error: Unexpected maze dimensions!\n");
        // return 1;
    }
    // Remove--*

    // Initially, consider all unknown spaces as not walls (false) except outer enclosing walls

    // Initializing vertical and horizontal maze walls status as false and Marking outer   enclosing walls based on MAZE_SIZE as true
    for (int i = 0; i < MAZE_SIZE + 1; i++)
    {

        for (int j = 0; j < MAZE_SIZE + 1; j++)
        {

            if (j == 0 && i < MAZE_SIZE)
            { // Making bottom edge wall of Arena as true
                horizontalWalls[i][j] = true;
                verticalWalls[i][j] = false;
                API_setWall(i, j, 's');
            }
            else if (i == 0 && j < MAZE_SIZE)
            { // Making left edge wall of Arena as true
                horizontalWalls[i][j] = false;
                verticalWalls[i][j] = true;
                API_setWall(i, j, 'w');
            }
            else if (j == MAZE_SIZE)
            { // Making top edge wall of Arena as true
                horizontalWalls[i][j] = true;
                API_setWall(i, j - 1, 'n');
            }
            else if (i == MAZE_SIZE)
            { // Making right edge wall of Arena as true
                verticalWalls[i][j] = true;
                API_setWall(i - 1, j, 'e');
            }
            else
            { // Making all inside walls of Arena as false
                horizontalWalls[i][j] = false;
                verticalWalls[i][j] = false;
            }
        }
    }

    // Initializing all cells as not visited
    for (int i = 0; i < MAZE_SIZE; i++)
    {
        for (int j = 0; j < MAZE_SIZE; j++)
        {
            isVisited[i][j] = false;
        }
    }

    // Initial FloodFill to calculate distances from goal cell position
    // (Maze representation starts with unknown spaces - no walls)
    FloodFill(horizontalWalls, verticalWalls, manhattanDistances, goalX, goalY);

    // Current cell position
    currentX = startX;
    currentY = startY;

    isMove = 0;

    log("Running..."); // Remove

    // Loop until goal is reached or error occurs
    // while (manhattanDistances[currentX][currentY] != 0)
    while (1)
    {
        if (manhattanDistances[currentX][currentY] != 0)
        {
            isMove = 0;

            // Check for accessible neighbors with lower Manhattan distances
            int lowerNeighborX = -1;
            int lowerNeighborY = -1;
            int lowestDistance = manhattanDistances[currentX][currentY];

            if (!isVisited[currentX][currentY])
            {
                scanCellWalls(currentX, currentY);
                isVisited[currentX][currentY] = true;
                // API_setColor(currentX,currentY,'w');
            }

            // for (int direction = 0; direction < 4; direction++)
            // {
            //     int nextOrientation = (current_orientation + direction) % 4;
            //     switch (nextOrientation)
            //     {
            //     case 0:
            //         if (manhattanDistances[currentX - 1][currentY] < lowestDistance && !verticalWalls[currentX][currentY])
            //         {
            //             lowestDistance = manhattanDistances[currentX - 1][currentY];
            //             lowerNeighborX = currentX - 1; 
            //             lowerNeighborY = currentY;
            //             isMove = 1;
            //             API_turnLeft();
            //             current_orientation = nextOrientation;
            //             break;
            //         }
            //         break;
            //     case 1:
            //         if (manhattanDistances[currentX][currentY + 1] < lowestDistance && !horizontalWalls[currentX][currentY+1])
            //         {
            //             lowestDistance = manhattanDistances[currentX][currentY + 1];
            //             lowerNeighborX = currentX;
            //             lowerNeighborY = currentY + 1;
            //             isMove = 1;
            //             // No turn needed as orientation is already 1
            //             current_orientation = nextOrientation;
            //             break;
            //         }
            //         break;
            //     case 2:
            //         if (manhattanDistances[currentX + 1][currentY] < lowestDistance && !verticalWalls[currentX + 1][currentY])
            //         {
            //             lowestDistance = manhattanDistances[currentX + 1][currentY];
            //             lowerNeighborX = currentX + 1;
            //             lowerNeighborY = currentY;
            //             isMove = 1;
            //             API_turnRight();
            //             current_orientation = nextOrientation;
            //             break;
            //         }
            //         break;
            //     case 3:
            //         if (manhattanDistances[currentX][currentY - 1] < lowestDistance && !horizontalWalls[currentX][currentY])
            //         { // Use wallRight here to check for opposite direction
            //             lowestDistance = manhattanDistances[currentX][currentY - 1];
            //             lowerNeighborX = currentX;
            //             lowerNeighborY = currentY - 1;
            //             isMove = 1;
            //             API_turnRight();
            //             API_turnRight();
            //             current_orientation = nextOrientation;
            //             break;
            //         }
            //         break;
            //     }

            //     // Exit the loop if a move is made
            //     if (isMove)
            //     {
            //         break;
            //     }
            // }

            // Handle case where robot is surrounded (no possible moves)
            // if (!isMove)
            // {
            //     API_turnRight();
            //     API_turnRight();
            //     current_orientation = (current_orientation + 2) % 4;
            //     isMove = 1;
            // }

            if (!API_wallLeft() && !isMove)
            {
                switch (current_orientation)
                {
                case 0:
                    if (currentX>0 && manhattanDistances[currentX - 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX - 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX - 1][currentY];
                        API_turnLeft();
                        current_orientation = (current_orientation - 1 + 4) % 4;
                        isMove = 1;
                    }
                    break;
                case 1:
                    if (currentY<(MAZE_SIZE-1) && manhattanDistances[currentX][currentY + 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY + 1;
                        lowestDistance = manhattanDistances[currentX][currentY + 1];
                        API_turnLeft();
                        current_orientation = (current_orientation - 1 + 4) % 4;
                        isMove = 1;
                    }
                    break;
                case 2:
                    if (currentX<(MAZE_SIZE-1) && manhattanDistances[currentX + 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX + 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX + 1][currentY];
                        API_turnLeft();
                        current_orientation = (current_orientation - 1 + 4) % 4;
                        isMove = 1;
                    }
                    break;
                case 3:
                    if (currentY>0 && manhattanDistances[currentX][currentY - 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY - 1;
                        lowestDistance = manhattanDistances[currentX][currentY - 1];
                        API_turnLeft();
                        current_orientation = (current_orientation - 1 + 4) % 4;
                        isMove = 1;
                    }
                    break;
                default:
                    log("\nInvalid Orientation when no left wall detected\n");
                    break;
                }
            }

            if (!API_wallFront() && !isMove)
            {
                switch (current_orientation)
                {
                case 0:
                    if (currentY<(MAZE_SIZE-1) && manhattanDistances[currentX][currentY + 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY + 1;
                        lowestDistance = manhattanDistances[currentX][currentY + 1];
                        isMove = 1;
                    }
                    break;
                case 1:
                    if (currentX<(MAZE_SIZE-1) && manhattanDistances[currentX + 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX + 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX + 1][currentY];
                        isMove = 1;
                    }
                    break;
                case 2:
                    if (currentY>0 && manhattanDistances[currentX][currentY - 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY - 1;
                        lowestDistance = manhattanDistances[currentX][currentY - 1];
                        isMove = 1;
                    }
                    break;
                case 3:
                    if (currentX>0 && manhattanDistances[currentX - 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX - 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX - 1][currentY];
                        isMove = 1;
                    }
                    break;
                default:
                    log("\nInvalid Orientation when no front wall detected\n");
                    break;
                }
            }

            if (!API_wallRight() && !isMove)
            {
                switch (current_orientation)
                {
                case 0:
                    if (currentX<(MAZE_SIZE-1) && manhattanDistances[currentX + 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX + 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX + 1][currentY];
                        API_turnRight();
                        current_orientation = (current_orientation + 1) % 4;
                        isMove = 1;
                    }
                    break;
                case 1:
                    if (currentY>0 && manhattanDistances[currentX][currentY - 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY - 1;
                        lowestDistance = manhattanDistances[currentX][currentY - 1];
                        API_turnRight();
                        current_orientation = (current_orientation + 1) % 4;
                        isMove = 1;
                    }
                    break;
                case 2:
                    if (currentX>0 && manhattanDistances[currentX - 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX - 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX - 1][currentY];
                        API_turnRight();
                        current_orientation = (current_orientation + 1) % 4;
                        isMove = 1;
                    }
                    break;
                case 3:
                    if (currentY<(MAZE_SIZE-1) && manhattanDistances[currentX][currentY + 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY + 1;
                        lowestDistance = manhattanDistances[currentX][currentY + 1];
                        API_turnRight();
                        current_orientation = (current_orientation + 1) % 4;
                        isMove = 1;
                    }
                    break;
                default:
                    log("\nInvalid Orientation when no right wall detected\n");
                    break;
                }
            }

            if (!isMove)
            {
                switch (current_orientation)
                {
                case 0:
                    if (currentY>0 && manhattanDistances[currentX][currentY - 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY - 1;
                        lowestDistance = manhattanDistances[currentX][currentY - 1];
                        API_turnRight();
                        API_turnRight();
                        current_orientation = (current_orientation + 2) % 4;
                        isMove = 1;
                    }
                    break;
                case 1:
                    if (currentX>0 && manhattanDistances[currentX - 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX - 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX - 1][currentY];
                        API_turnRight();
                        API_turnRight();
                        current_orientation = (current_orientation + 2) % 4;
                        isMove = 1;
                    }
                    break;
                case 2:
                    if (currentY<(MAZE_SIZE-1) && manhattanDistances[currentX][currentY + 1] < lowestDistance)
                    {
                        lowerNeighborX = currentX;
                        lowerNeighborY = currentY + 1;
                        lowestDistance = manhattanDistances[currentX][currentY + 1];
                        API_turnRight();
                        API_turnRight();
                        current_orientation = (current_orientation + 2) % 4;
                        isMove = 1;
                    }
                    break;
                case 3:
                    if (currentX<(MAZE_SIZE-1) && manhattanDistances[currentX + 1][currentY] < lowestDistance)
                    {
                        lowerNeighborX = currentX + 1;
                        lowerNeighborY = currentY;
                        lowestDistance = manhattanDistances[currentX + 1][currentY];
                        API_turnRight();
                        API_turnRight();
                        current_orientation = (current_orientation + 2) % 4;
                        isMove = 1;
                    }
                    break;
                default:
                    log("\nInvalid Orientation when no back wall detected\n");
                    break;
                }
            }

            // Move to the neighbor with the lowest distance
            if ((lowerNeighborX != -1 && lowerNeighborY != -1))
            {
                // Update current position and Manhattan distance
                currentX = lowerNeighborX;
                currentY = lowerNeighborY;

                // Move the Micromouse (use your movement API)
                if (API_moveForward() == 0)
                {
                    log("Error: Crash detected!\n");
                    break; // Exit loop if crash occurs
                } 
            }
            else
            {
                // Stuck situation: No accessible neighbors with lower distances
                log("Stuck situation! Re-calculating Manhattan distances...\n");

                // Re-calculate Manhattan distances from current position
                FloodFill(horizontalWalls, verticalWalls, manhattanDistances, goalX, goalY);
            }
        }
        else if (manhattanDistances[currentX][currentY] == 0)
        {                                 // This going to be the external interrupt like switch will run when switch is pressed
            log("\nReached Goal Cell\n"); // Remove
            API_ackReset();               // Remove

            // Reset current position to start position
            currentX = startX;
            currentY = startY;
            current_orientation = 0;
        }
    }
}
