#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <Wire.h>

#define MAZE_SIZE 7

#define NULL 0

// Initialize maze representation (No walls)
bool horizontalWalls[MAZE_SIZE][MAZE_SIZE + 1];
bool verticalWalls[MAZE_SIZE + 1][MAZE_SIZE];

// Initialize manhattan distances array (all -1 initially)
int manhattanDistances[MAZE_SIZE][MAZE_SIZE];

// Array stating cell is visited or not
bool isVisited[MAZE_SIZE][MAZE_SIZE];

// Get starting position (start cell coordinates)
int startX = 0;
int startY = 0;

// Get goal cell coordinates (assuming there's only one goal)
int goalX = 4;
int goalY = 3;

// Structure to represent each cell(in form of coordinates)
typedef struct
{
    int x;
    int y;
} Cell;

// Keeping track of current orientation
int current_orientation = 0;
char dir[4] = {'n', 'e', 's', 'w'};

// Current cell position
int currentX;
int currentY;

// int *current_path = NULL;
// int *shortest_path = NULL;
int current_path[400];
int shortest_path[400];

int current_path_len = 0;
int shortest_path_len = __INT_MAX__;

int isMove = 0;

int run_count = 0;

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Define pins for ultrasonic sensors
const int trigPin1 = 12;
const int echoPin1 = 13; //--right
const int trigPin2 = 10;
const int echoPin2 = 11; //--left
const int trigPin3 = 36;
const int echoPin3 = 38; //-front

const int irL = A10;
const int irR = A9;

float distance1;
float distance2;
float distance3;

#define MotFwd 5 // Motor Forward pin
#define MotRev 4 // Motor Reverse pin

#define MotFwd2 6 // Motor Forward pin
#define MotRev2 7 // Motor Reverse pin

const int motor1EnablePin = 8;

const int motor2EnablePin = 9;

int encoderPin1 = 18;           // Encoder Output 'A' must connected with intreput pin of arduino.
int encoderPin2 = 19;           // Encoder Otput 'B' must connected with intreput pin of arduino.
volatile int lastEncoded = 0;   // Here updated value of encoder store.
volatile long encoderValue = 0; // Raw encoder value

int encoder2Pin1 = 2;            // Encoder Output 'A' must connected with intreput pin of arduino.
int encoder2Pin2 = 3;            // Encoder Otput 'B' must connected with intreput pin of arduino.
volatile int lastEncoded2 = 0;   // Here updated value of encoder store.
volatile long encoderValue2 = 0; // Raw encoder value

const int encoderCountsPerRotation = 650;

int irLeft()
{
    int l = digitalRead(irL);
    if (l == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int irRight()
{
    int r = digitalRead(irR);
    if (r == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool API_wallFront()
{
    // Code for detecting front wall (if any)
    distance3 = readDistance(trigPin3, echoPin3);
    Serial.print("Distance F: ");
    Serial.print(distance3);
    Serial.println(" cm");

    if (distance3 < 12)
    {
        Serial.println("FrontWall");
        return 1;
    }
    else
    {
        return 0;
    }
    delay(100);
}

bool API_wallRight()
{
    // Code for detecting wall on Right (if any)
    distance1 = readDistance(trigPin1, echoPin1);
    Serial.print("Distance R: ");
    Serial.print(distance1);
    Serial.println(" cm");

    if (distance1 < 12)
    {
        Serial.println("RightWall");
        return 1;
    }
    else
    {
        return 0;
    }
    delay(100);
}

bool API_wallLeft()
{
    // Code for detecting wall on Left (if any)
    distance2 = readDistance(trigPin2, echoPin2);
    Serial.print("Distance R: ");
    Serial.print(distance2);
    Serial.println(" cm");

    if (distance2 < 12)
    {
        Serial.println("RightWall");
        return 1;
    }
    else
    {
        return 0;
    }
    delay(100);
}

void sensorCheck()
{
    API_wallRight();
    API_wallFront();
    API_wallLeft();
    irLeft();
    irRight();
}

float readDistance(int trigPin, int echoPin)
{
    // Clear trigger pin
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);

    // Send a 10 microsecond pulse to trigger pin
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);

    // Measure the duration of the pulse on the echo pin
    long duration = pulseIn(echoPin, HIGH);

    // Convert duration to distance (cm)
    float distance = duration * 0.0343 / 2;

    return distance;
}

int API_moveForward(int x)
{
    // Code for moving mouse 'x' cells in forward direction
    moveDistance(1);
    return 1;
}

void API_turnRight()
{
    // Code for turning toward it's right in same cell
    moveRight();

    delay(100);
}

void API_turnLeft()
{
    // Code for turning toward it's Left in same cell
    moveLeft();

    delay(100);
}

void API_turnBack()
{
    // Code for turning backwards in same cell
    moveback();

    delay(100);
}

void updateEncoder()
{
    int MSB = digitalRead(encoderPin1); // MSB = most significant bit
    int LSB = digitalRead(encoderPin2); // LSB = least significant bit

    int encoded = (MSB << 1) | LSB;         // converting the 2 pin value to single number
    int sum = (lastEncoded << 2) | encoded; // adding it to the previous encoded value

    if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011)
        encoderValue--;
    if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000)
        encoderValue++;

    lastEncoded = encoded; // store this value for next time
}

void updateEncoder2()
{
    int MSB = digitalRead(encoder2Pin1); // MSB = most significant bit
    int LSB = digitalRead(encoder2Pin2); // LSB = least significant bit

    int encoded = (MSB << 1) | LSB;          // converting the 2 pin value to single number
    int sum = (lastEncoded2 << 2) | encoded; // adding it to the previous encoded value

    if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011)
        encoderValue2--;
    if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000)
        encoderValue2++;

    lastEncoded2 = encoded; // store this value for next time
}

void forward1()
{
    digitalWrite(MotFwd, LOW);
    digitalWrite(MotRev, HIGH);
    analogWrite(motor1EnablePin, 250);
}

void forward2()
{
    digitalWrite(MotFwd2, LOW);
    digitalWrite(MotRev2, HIGH);
    analogWrite(motor2EnablePin, 250);
}

void stop1()
{
    digitalWrite(MotFwd, LOW);
    digitalWrite(MotRev, HIGH);
    analogWrite(motor1EnablePin, 0);
}

void stop2()
{
    digitalWrite(MotFwd2, LOW);
    digitalWrite(MotRev2, HIGH);
    analogWrite(motor2EnablePin, 0);
}

void moveDistance(int rotations)
{
    while (rotations > 0)
    {
        long targetCount = 1 * encoderCountsPerRotation;
        encoderValue = 0;  // Reset encoder value for motor 1
        encoderValue2 = 0; // Reset encoder value for motor 2

        bool motor1Done = false;
        bool motor2Done = false;

        while (!motor1Done || !motor2Done)
        {
            if (!motor1Done)
            {
                if (abs(encoderValue) < targetCount)
                {
                    forward1();
                }
                else
                {
                    stop1();
                    motor1Done = true;
                }
            }

            if (!motor2Done)
            {
                if (abs(encoderValue2) < targetCount)
                {
                    forward2();
                }
                else
                {
                    stop2();
                    motor2Done = true;
                }
            }

            Serial.print("Encoder1: ");
            Serial.print(encoderValue);
            Serial.print(" Encoder2: ");
            Serial.println(encoderValue2);
        }

        stop1();
        stop2();
        Serial.println("-----------------------------------------------------------------------------");
        rotations = rotations - 1;
        delay(100);
    }
}

void moveRight()
{
    encoderValue = 0;  // Reset encoder value for motor 1
    encoderValue2 = 0; // Reset encoder value for motor 24
    int targetCount1 = -250;
    int targetCount2 = 230;
    bool motor1Done = false;
    bool motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue > targetCount1)
            {
                right1();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (abs(encoderValue2) < targetCount2)
            {
                right2();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
    delay(100);
    // Move back slightly to correct forward drift
    encoderValue = 0;           // Reset encoder value for motor 1
    encoderValue2 = 0;          // Reset encoder value for motor 2
    int correctionCount = -100; // Number of ticks to move backward

    motor1Done = false;
    motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue > correctionCount)
            {
                back1();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (encoderValue2 > correctionCount)
            {
                back2();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Correction Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Correction Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
}

void moveLeft()
{
    encoderValue = 0;  // Reset encoder value for motor 1
    encoderValue2 = 0; // Reset encoder value for motor 24
    int targetCount1 = 260;
    int targetCount2 = -270;
    bool motor1Done = false;
    bool motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue < targetCount1)
            {
                left1();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (encoderValue2 > targetCount2)
            {
                left2();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
    delay(100);
    // Move back slightly to correct forward drift
    encoderValue = 0;           // Reset encoder value for motor 1
    encoderValue2 = 0;          // Reset encoder value for motor 2
    int correctionCount = -100; // Number of ticks to move backward

    motor1Done = false;
    motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue > correctionCount)
            {
                back1();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (encoderValue2 > correctionCount)
            {
                back2();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Correction Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Correction Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
}

void moveback()
{
    encoderValue = 0;  // Reset encoder value for motor 1
    encoderValue2 = 0; // Reset encoder value for motor 24
    int targetCount1 = -740;
    int targetCount2 = 700;
    bool motor1Done = false;
    bool motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue > targetCount1)
            {
                right3();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (abs(encoderValue2) < targetCount2)
            {
                right4();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
    delay(100);
    // Move back slightly to correct forward drift
    encoderValue = 0;           // Reset encoder value for motor 1
    encoderValue2 = 0;          // Reset encoder value for motor 2
    int correctionCount = -100; // Number of ticks to move backward

    motor1Done = false;
    motor2Done = false;

    while (!motor1Done || !motor2Done)
    {
        if (!motor1Done)
        {
            if (encoderValue > correctionCount)
            {
                back1();
            }
            else
            {
                stop1();
                motor1Done = true;
            }
        }

        if (!motor2Done)
        {
            if (encoderValue2 > correctionCount)
            {
                back2();
            }
            else
            {
                stop2();
                motor2Done = true;
            }
        }

        Serial.print("Correction Encoder1: ");
        Serial.print(encoderValue);
        Serial.print(" Correction Encoder2: ");
        Serial.println(encoderValue2);
    }

    stop1();
    stop2();

    Serial.println("-----------------------------------------------------------------------------");
}

void right1()
{
    digitalWrite(MotFwd, HIGH);
    digitalWrite(MotRev, LOW);
    analogWrite(motor1EnablePin, 200);
}

void right2()
{
    digitalWrite(MotFwd2, LOW);
    digitalWrite(MotRev2, HIGH);
    analogWrite(motor2EnablePin, 200);
}

void right3()
{
    digitalWrite(MotFwd, HIGH);
    digitalWrite(MotRev, LOW);
    analogWrite(motor1EnablePin, 250);
}

void right4()
{
    digitalWrite(MotFwd2, LOW);
    digitalWrite(MotRev2, HIGH);
    analogWrite(motor2EnablePin, 250);
}

void left1()
{
    digitalWrite(MotFwd, LOW);
    digitalWrite(MotRev, HIGH);
    analogWrite(motor1EnablePin, 200);
}

void left2()
{
    digitalWrite(MotFwd2, HIGH);
    digitalWrite(MotRev2, LOW);
    analogWrite(motor2EnablePin, 200);
}

void back()
{
    digitalWrite(MotFwd, HIGH);
    digitalWrite(MotRev, LOW);
    analogWrite(motor1EnablePin, 100);
    digitalWrite(MotFwd2, HIGH);
    digitalWrite(MotRev2, LOW);
    analogWrite(motor2EnablePin, 100);
}

void back1()
{
    digitalWrite(MotFwd, HIGH);
    digitalWrite(MotRev, LOW);
    analogWrite(motor1EnablePin, 230);
}

void back2()
{
    digitalWrite(MotFwd2, HIGH);
    digitalWrite(MotRev2, LOW);
    analogWrite(motor2EnablePin, 230);
}

// Dequeue a cell from the queue (circular array implementation)
Cell *dequeue(Cell queue[40], int *front, int *rear)
{
    if (*front == -1)
    {
        return NULL; // Queue is empty
    }

    Cell *cell = &queue[*front];

    if (*front == *rear)
    {
        *front = *rear = -1; // Reset front and rear if queue becomes empty
    }
    else
    {
        *front = (*front + 1) % 40; // Update front index (circular)
    }

    return cell;
}

// Enqueue a Cell into queue (circular array implementation)
void enqueue(Cell queue[40], int *front, int *rear, Cell cell)
{
    *rear = (*rear + 1) % 40; // Update rear index (circular)

    if (*front == -1)
    {
        *front = 0; // Initialize front if queue was empty
    }

    // Check for overflow (avoid overwriting existing elements)
    if ((*rear + 1) % 40 == *front)
    {
        // Queue overflow!
        return;
    }

    queue[*rear] = cell; // Add cell to the queue
}

// FloodFill function to repopulate the ManhattenDistances array
void FloodFill(bool horizontalWalls[MAZE_SIZE][MAZE_SIZE + 1], bool verticalWalls[MAZE_SIZE + 1][MAZE_SIZE], int manhattanDistances[MAZE_SIZE][MAZE_SIZE], int goalX, int goalY)
{
    // Initialize all cells to blank state (-1)
    for (int i = 0; i < MAZE_SIZE; i++)
    {
        for (int j = 0; j < MAZE_SIZE; j++)
        {
            manhattanDistances[i][j] = -1;
        }
    }

    // Set goal cell(s) value to 0 and add to queue
    manhattanDistances[goalX][goalY] = 0;

    // Declaring a circular queue
    Cell queue[40];
    int front = -1;
    int rear = -1;
    enqueue(queue, &front, &rear, (Cell){goalX, goalY});

    while (front != -1)
    {
        Cell currentCell = *dequeue(queue, &front, &rear);
        int currentX = currentCell.x;
        int currentY = currentCell.y;

        // if(currentX == x && currentY == y){
        //     front=rear=-1;
        // }

        // Check and update accessible neighbors (only north, south, east, west and Not Diagonal cells)
        // Check every other value (skip 0 for no diagonal movement)
        for (int dx = -1; dx <= 1; dx += 2)
        {
            int dy = 0; // Only check left and right cells

            int neighborX = currentX + dx;
            int neighborY = currentY + dy;

            // Skip current cell and check if neighbor is within maze boundaries
            if (neighborX < 0 || neighborX >= MAZE_SIZE || neighborY < 0 || neighborY >= MAZE_SIZE)
            {
                continue;
            }

            // Check if neighbor is accessible (not a wall based on direction)
            bool isAccessible = true;
            if (dx == -1)
            { // Checking left neighbor
                isAccessible = !verticalWalls[currentX][currentY];
            }
            else if (dx == 1)
            { // Checking right neighbor
                isAccessible = !verticalWalls[currentX + 1][currentY];
            }

            // Checking if neighbour is accessible and in a blank state
            if (isAccessible && manhattanDistances[neighborX][neighborY] == -1)
            {
                manhattanDistances[neighborX][neighborY] = manhattanDistances[currentX][currentY] + 1;
                enqueue(queue, &front, &rear, (Cell){neighborX, neighborY});
            }
        }

        for (int dy = -1; dy <= 1; dy += 2)
        {               // Check every other value (skip 0 for no diagonal movement)
            int dx = 0; // Only check front and back cell

            int neighborX = currentX + dx;
            int neighborY = currentY + dy;

            // Skip current cell and check if neighbor is within maze boundaries
            if (neighborX < 0 || neighborX >= MAZE_SIZE || neighborY < 0 || neighborY >= MAZE_SIZE)
            {
                continue;
            }

            // Check if neighbor is accessible (not a wall based on direction)
            bool isAccessible = true;
            if (dy == -1)
            { // Checking bottom neighbor
                isAccessible = !horizontalWalls[currentX][currentY];
            }
            else if (dy == 1)
            { // Checking front neighbor
                isAccessible = !horizontalWalls[currentX][currentY + 1];
            }

            // Checking if neighbour is accessible and in a blank state
            if (isAccessible && manhattanDistances[neighborX][neighborY] == -1)
            {
                manhattanDistances[neighborX][neighborY] = manhattanDistances[currentX][currentY] + 1;
                enqueue(queue, &front, &rear, (Cell){neighborX, neighborY});
            }
        }
    }
}

void initializeMaze()
{
    // Initially, consider all unknown spaces as not walls (false) except outer enclosing walls

    // Initializing vertical and horizontal maze walls status as false and Marking outer   enclosing walls based on MAZE_SIZE as true
    for (int i = 0; i < MAZE_SIZE + 1; i++)
    {

        for (int j = 0; j < MAZE_SIZE + 1; j++)
        {

            if (j == 0 && i < MAZE_SIZE)
            { // Making bottom edge wall of Arena as true
                horizontalWalls[i][j] = true;
                verticalWalls[i][j] = false;
            }
            else if (i == 0 && j < MAZE_SIZE)
            { // Making left edge wall of Arena as true
                horizontalWalls[i][j] = false;
                verticalWalls[i][j] = true;
            }
            else if (j == MAZE_SIZE)
            { // Making top edge wall of Arena as true
                horizontalWalls[i][j] = true;
            }
            else if (i == MAZE_SIZE)
            { // Making right edge wall of Arena as true
                verticalWalls[i][j] = true;
            }
            else
            { // Making all inside walls of Arena as false
                horizontalWalls[i][j] = false;
                verticalWalls[i][j] = false;
            }
        }
    }
}

void scanCellWalls(int currentX, int currentY)
{
    // Update maze representation based on detected walls (optional)
    if (API_wallLeft())
    {
        switch (current_orientation)
        {
        case 0:
            verticalWalls[currentX][currentY] = true;
            break;
        case 1:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        case 2:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 3:
            horizontalWalls[currentX][currentY] = true;
            break;
        default:
            // Invalid Orientation
            break;
        }
    }
    if (API_wallRight())
    {
        switch (current_orientation)
        {
        case 0:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 1:
            horizontalWalls[currentX][currentY] = true;
            break;
        case 2:
            verticalWalls[currentX][currentY] = true;
            break;
        case 3:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        default:
            // Invalid Orientation
            break;
        }
    }
    if (API_wallFront())
    {
        switch (current_orientation)
        {
        case 0:
            horizontalWalls[currentX][currentY + 1] = true;
            break;
        case 1:
            verticalWalls[currentX + 1][currentY] = true;
            break;
        case 2:
            horizontalWalls[currentX][currentY] = true;
            break;
        case 3:
            verticalWalls[currentX][currentY] = true;
            break;
        default:
            // Invalid Orientation
            break;
        }
    }
}

void *movementThread(int cmnd, int c)
{

    if (cmnd == 0)
    {
        API_turnRight();
    }
    else if (cmnd == 1)
    {
        API_turnLeft();
    }
    else if (cmnd == 2)
    {
        API_turnBack();
    }
    else if (cmnd >= 3)
    {
        API_moveForward(c);
    }
    else
    {
        log("Invalid movement command\n");
    }

    return NULL;
}

void moveWest()
{
    switch (current_orientation)
    {
    case 0:
        API_turnLeft();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 1;
        current_orientation = (current_orientation - 1 + 4) % 4;
        break;
    case 1:
        API_turnBack();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 2;
        current_orientation = (current_orientation + 2) % 4;
        break;
    case 2:
        API_turnRight();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 0;
        current_orientation = (current_orientation + 1) % 4;
        break;
    case 3:
        break;
    }
}

void moveNorth()
{
    switch (current_orientation)
    {
    case 0:
        break;
    case 1:
        API_turnLeft();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 1;
        current_orientation = (current_orientation - 1 + 4) % 4;
        break;
    case 2:
        API_turnBack();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 2;
        current_orientation = (current_orientation + 2) % 4;
        break;
    case 3:
        API_turnRight();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 0;
        current_orientation = (current_orientation + 1) % 4;
        break;
    }
}

void moveEast()
{
    switch (current_orientation)
    {
    case 0:
        API_turnRight();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 0;
        current_orientation = (current_orientation + 1) % 4;
        break;
    case 1:
        break;
    case 2:
        API_turnLeft();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 1;
        current_orientation = (current_orientation - 1 + 4) % 4;
        break;
    case 3:
        API_turnBack();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 2;
        current_orientation = (current_orientation + 2) % 4;
        break;
    }
}

void moveSouth()
{
    switch (current_orientation)
    {
    case 0:
        API_turnBack();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 2;
        current_orientation = (current_orientation + 2) % 4;
        break;
    case 1:
        API_turnRight();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 0;
        current_orientation = (current_orientation + 1) % 4;
        break;
    case 2:
        break;
    case 3:
        API_turnLeft();
        current_path_len++;
        // current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
        current_path[current_path_len - 1] = 1;
        current_orientation = (current_orientation - 1 + 4) % 4;
        break;
    }
}

void copyArray()
{
    for (int i = 0; i < current_path_len; i++)
    {
        shortest_path[i] = current_path[i];
    }
}

void restartMazeISR()
{
    // Reset current position to start position
    currentX = startX;
    currentY = startY;
    current_orientation = 0;
    // SHIV-editz
    if (current_path_len < shortest_path_len && current_path_len != 0)
    {
        // shortest_path = current_path;
        copyArray();
        shortest_path_len = current_path_len;
    }
    // current_path = NULL;
    current_path_len = 0;
    run_count++;
}

void setup()
{
    // put your setup code here, to run once:
    Serial.begin(9600);

    pinMode(trigPin1, OUTPUT);
    pinMode(trigPin2, OUTPUT);
    pinMode(trigPin3, OUTPUT);

    // Set echo pins as inputs
    pinMode(echoPin1, INPUT);
    pinMode(echoPin2, INPUT);
    pinMode(echoPin3, INPUT);

    // IR
    pinMode(irL, INPUT);
    pinMode(irR, INPUT);

    //
    pinMode(MotFwd, OUTPUT);
    pinMode(MotRev, OUTPUT);
    pinMode(motor1EnablePin, OUTPUT);

    pinMode(MotFwd2, OUTPUT);
    pinMode(MotRev2, OUTPUT);
    pinMode(motor2EnablePin, OUTPUT);
    // initialize serial comunication

    pinMode(encoderPin1, INPUT_PULLUP);
    pinMode(encoderPin2, INPUT_PULLUP);

    pinMode(encoder2Pin1, INPUT_PULLUP);
    pinMode(encoder2Pin2, INPUT_PULLUP);

    digitalWrite(encoderPin1, HIGH); // turn pullup resistor on
    digitalWrite(encoderPin2, HIGH); // turn pullup resistor on

    digitalWrite(encoder2Pin1, HIGH); // turn pullup resistor on
    digitalWrite(encoder2Pin2, HIGH); // turn pullup resistor on
    // call updateEncoder() when any high/low changed seen
    // on interrupt 0 (pin 2), or interrupt 1 (pin 3)
    attachInterrupt(digitalPinToInterrupt(18), updateEncoder, CHANGE);
    attachInterrupt(digitalPinToInterrupt(19), updateEncoder, CHANGE);

    attachInterrupt(digitalPinToInterrupt(2), updateEncoder2, CHANGE);
    attachInterrupt(digitalPinToInterrupt(3), updateEncoder2, CHANGE);

    // attachInterrupt(digitalPinToInterrupt(6), restartMazeISR, RISING); // Attach interrupt for restart Maze pin

    // Initializing Maze(only borders)
    initializeMaze();

    // Initializing all cells as not visited
    for (int i = 0; i < MAZE_SIZE; i++)
    {
        for (int j = 0; j < MAZE_SIZE; j++)
        {
            isVisited[i][j] = false;
        }
    }

    // Current cell position
    currentX = startX;
    currentY = startY;

    // Initial FloodFill to calculate distances from goal cell position
    // (Maze representation starts with unknown spaces - no walls)
    FloodFill(horizontalWalls, verticalWalls, manhattanDistances, goalX, goalY);
}

void loop()
{
    // put your main code here, to run repeatedly:
    // Loop until goal is reached or error occurs
    // while (manhattanDistances[currentX][currentY] != 0)
    delay(200);
    if (manhattanDistances[currentX][currentY] != 0)
    {
        if (run_count >= 3)
        {
            int k;
            for (int i = 0; i < shortest_path_len; i++)
            {
                k = 0;
                if (shortest_path[i] == 3)
                {
                    while (shortest_path[i] == 3)
                    {
                        k++;
                        i++;
                    }
                    i--;
                }
                movementThread(shortest_path[i], k);
            }
            currentX = goalX;
            currentY = goalY;
        }
        else
        {
            isMove = 0;

            // Check for accessible neighbors with lower Manhattan distances
            int lowerNeighborX = -1;
            int lowerNeighborY = -1;
            int lowestDistance = manhattanDistances[currentX][currentY];

            if (!isVisited[currentX][currentY])
            {
                scanCellWalls(currentX, currentY);
                isVisited[currentX][currentY] = true;
            }

                for (int direction = 0; direction < 4; direction++)
                {
                    int nextOrientation = (current_orientation + direction) % 4;
                    switch (nextOrientation)
                    {
                    case 0:
                        if (manhattanDistances[currentX - 1][currentY] < lowestDistance && !verticalWalls[currentX][currentY])
                        {
                            lowestDistance = manhattanDistances[currentX - 1][currentY];
                            lowerNeighborX = currentX - 1;
                            lowerNeighborY = currentY;
                            isMove = 1;
                            moveWest();
                            break;
                        }
                        break;
                    case 1:
                        if (manhattanDistances[currentX][currentY + 1] < lowestDistance && !horizontalWalls[currentX][currentY + 1])
                        {
                            lowestDistance = manhattanDistances[currentX][currentY + 1];
                            lowerNeighborX = currentX;
                            lowerNeighborY = currentY + 1;
                            isMove = 1;
                            moveNorth();
                            break;
                        }
                        break;
                    case 2:
                        if (manhattanDistances[currentX + 1][currentY] < lowestDistance && !verticalWalls[currentX + 1][currentY])
                        {
                            lowestDistance = manhattanDistances[currentX + 1][currentY];
                            lowerNeighborX = currentX + 1;
                            lowerNeighborY = currentY;
                            isMove = 1;
                            moveEast();
                            break;
                        }
                        break;
                    case 3:
                        if (manhattanDistances[currentX][currentY - 1] < lowestDistance && !horizontalWalls[currentX][currentY])
                        { // Use wallRight here to check for opposite direction
                            lowestDistance = manhattanDistances[currentX][currentY - 1];
                            lowerNeighborX = currentX;
                            lowerNeighborY = currentY - 1;
                            isMove = 1;
                            moveSouth();
                            break;
                        }
                        break;
                    }

                    // Exit the loop if a move is made
                    if (isMove)
                    {
                        break;
                    }
                }

            // Move to the neighbor with the lowest distance
            if ((lowerNeighborX != -1 && lowerNeighborY != -1))
            {
                // Update current position and Manhattan distance
                currentX = lowerNeighborX;
                currentY = lowerNeighborY;

                // Move the Micromouse (use your movement API)
                if (API_moveForward(1) == 0)
                {
                    // Error: Crash detected!
                    //                        break; // Exit loop if crash occurs
                }
                else
                {
                    // SHIV-editz
                     current_path_len++;
                    //  current_path = (int *)realloc(current_path, current_path_len * sizeof(int));
                     current_path[current_path_len - 1] = 3;
                }
            }
            else
            {
                // Stuck situation: No accessible neighbors with lower distances
                // Re-calculate Manhattan distances from current position
                FloodFill(horizontalWalls, verticalWalls, manhattanDistances, goalX, goalY);
            }
        }
    }
    else
    {
        delay(6000);
        restartMazeISR();
    }
    // API_wallFront();
    // sensorCheck();
    //  API_turnLeft();
    //  API_turnBack();
    //  delay(1000);
}